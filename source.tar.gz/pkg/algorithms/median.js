const getMedian = (input) => input[Math.floor(input.length / 2) - 1];

module.exports = {
  getMedian,
};
